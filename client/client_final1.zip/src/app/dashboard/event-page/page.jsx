'use client'
import EventDetailPage from '@/components/EventPage/EventDetailPage'
import EventPage from '@/components/EventPage/EventPage'
import React from 'react'

const eventPage = () => {
  return (
    <div className=''>
      <EventPage/>
    </div>
  )
}

export default eventPage