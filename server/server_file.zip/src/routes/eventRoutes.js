const router = require('express').Router();
const eventController = require('../controllers/eventController.js');
const authController = require("../controllers/auth.contollers.js");

router.get('/all-posted-events',authController.protectGeneralUser,eventController.getAllPostedEvents);
router.post('/create-personal-event', eventController.createPersonalEvent);
router.post('/create-event', eventController.createPostedEvent);
router.get('/user-events', authController.protectGeneralUser,eventController.getUserEvents);
router.post('/all-organization-events', eventController.getAllPostedEventsByAdmin);
router.post('/event-details', eventController.getEventDetails);
router.post('/add-event', eventController.addEventToUser);

module.exports = router;