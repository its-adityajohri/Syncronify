// export { login } from './authentication.controller';
export { index, store, show, update } from './user.controller';
