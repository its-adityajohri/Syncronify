const dotenv = require('dotenv');
const cors = require('cors');
const express = require('express');
// const webRoutes = require('./routes/web'); // Uncomment and adjust the path as necessary
const authRoutes = require('./routes/authMain.js');
const eventRoutes = require('./routes/eventRoutes.js');
const errorHandler = require('./middleware/errorHandler.js');



dotenv.config();
const app = express();
app.use(cors({
  origin: 'http://localhost:3000', // Allow requests from this origin
  credentials: true // Allow credentials (cookies, authorization headers, etc.)
}));

app.use(express.json());
// app.use("/", express.static(path.join(__dirname,"./uploads")));
app.use('/health', (req, res) => res.status(200).send({ message: 'Synchronify Http and Tcp-socket servers are running' }));
// app.use('/api', webRoutes); // Uncomment when webRoutes are converted to CommonJS
app.use('/api/auth', authRoutes);
app.use('/api', eventRoutes);

app.use(errorHandler);

module.exports = app;


// import dotenv from 'dotenv';
// import cors from 'cors';
// import express from 'express';
// // import webRoutes from './routes/web';
// import authRoutes from './routes/authMain.js';
// import errorHandler from './middleware/errorHandler.js';

// dotenv.config();
// const app = express();
// app.use(cors());

// app.use(express.json());

// app.use('/health', (req, res) => res.status(200).send({message : 'Synchronify Http and Tcp-socket servers are running'}))
// app.use('/api', webRoutes);
// app.use('./api/auth', authRoutes);
// app.use(errorHandler);


// export default appMain;